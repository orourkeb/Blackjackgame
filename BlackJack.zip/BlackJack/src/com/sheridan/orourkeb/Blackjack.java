/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sheridan.orourkeb;
import java.util.*;
/**
 *
 * @author benja
 */
public class Blackjack {
    
    public static void main(String[] args){
        System.out.println("Welcome to BlackJack. ");
        
        //create Scanner for user input
        Scanner sc = new Scanner(System.in);
        
        //Create player deck
        Deck gameDeck = new Deck();
        
        //player deck now has access to all 52 cards, which will be randomly
        //pulled into another deck.
        gameDeck.generateCards();
        
        //.shuffle() will shuffle the cards into a random order to be 
        //eventually picked from
        gameDeck.shuffle();
        
        //Create a deck for player
        Deck playerDeck = new Deck();
        
        //Create a deck for the dealer
        Deck dealerDeck = new Deck();
        
        //Can be customizable, but player will automatically start with $500
        double playerMoney = 500.00;
        
        while (playerMoney > 0){
            
            System.out.println("You have $" + playerMoney);
            System.out.println("How much money would you like to bet? ");
            double playerBet = sc.nextDouble();
            
            //deal two cards to the player
            playerDeck.drawDeck(gameDeck);
            playerDeck.drawDeck(gameDeck);
            
            //deal two cards to the dealer
            dealerDeck.drawDeck(gameDeck);
            dealerDeck.drawDeck(gameDeck);
            
            boolean round = false;
            
            //create loop to allow player to play multiple rounds
            //loop will be killed if player runs out of money.
            while (true){
                System.out.println("Your hand: ");
                System.out.println(playerDeck.toString());
                System.out.println("Deck value: " + playerDeck.cardsValue());
                
                //Display dealer's first card, second card remains hidden
                System.out.println("Dealer hand: " 
                        + dealerDeck.getCard(0).toString() + " and [**]");
                
                //prompt user to see if they would like to draw another card, 
                //or keep their current deck
                System.out.println("What would you like to (1)Hit or (2)Keep "
                        + "your deck");
                int userOption = sc.nextInt();
                
                //if user draws another card, display card and new deck total
                if (userOption == 1){
                    playerDeck.drawDeck(gameDeck);
                    System.out.println("You drawed a " 
                            + playerDeck.getCard(playerDeck.deckSize() - 1).toString());
                    System.out.println("Current total: " 
                                + playerDeck.cardsValue());
                    //if player's card total exceeds 21, player loses, and loses
                    //the money amount he previously betted.
                    if (playerDeck.cardsValue() > 21){
                        System.out.println("Oops! Your deck total's gone over"
                                + " 21.");
                        System.out.println("Current total: " 
                                + playerDeck.cardsValue());
                        
                        playerMoney -= playerBet;
                        round = true;
                        break;
                    }
                    
                }
                //if user chooses not to pick a card, kill loop and show results
                if (userOption == 2){
                     break;
                }
                break;
            }
            //Reveal dealer cards
            System.out.println("Dealer cards: " + dealerDeck.toString());
            
            //Check to see if dealer wins
            if ((dealerDeck.cardsValue() > playerDeck.cardsValue()) 
                    && round == false){
                System.out.println("Dealer wins!");
                playerMoney -= playerBet;
                round = true;
            }
            
            //Dealer will be set to draw if total is below 16
            while((dealerDeck.cardsValue() < 16) && round == false){
                dealerDeck.drawDeck(gameDeck);
                System.out.println("Dealer draws: " 
                        + dealerDeck.getCard(dealerDeck.deckSize() -1).toString());
            }
            System.out.println("Dealer total: " + dealerDeck.cardsValue());
            //Determine if dealer has exceeded 21
            
            if ((dealerDeck.cardsValue() > 21)){
                System.out.println("Dealer exceeded 21! You win!");
                playerMoney += (playerBet * 1.5);
            }
            
            //If total is tied between player and Dealer
            if ((playerDeck.cardsValue() == dealerDeck.cardsValue() 
                    && round == false)){
                System.out.println("It's a tie!");
                round = true;
            }
            if ((playerDeck.cardsValue() > dealerDeck.cardsValue() && round == false)){
                System.out.println("You win!!");
                playerMoney += (playerBet * 1.5);
                round = true;
            }
            playerDeck.resetDeck(gameDeck);
            dealerDeck.resetDeck(gameDeck);
            System.out.println("End of round. ");
        }
        
        System.out.println("Game over! You have run out of money. ");
    }
    
}
