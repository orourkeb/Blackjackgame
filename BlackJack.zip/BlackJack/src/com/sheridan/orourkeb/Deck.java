/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sheridan.orourkeb;
import java.util.ArrayList;
import java.util.*;

/**
 *
 * @author benja
 */
public class Deck {
    private ArrayList<Card> cards;
    
    public Deck(){
        this.cards = new ArrayList<Card>();
    }
    
    public void generateCards(){
        for (Suit cardSuit: Suit.values()){
            for (Value cardValue: Value.values()){
                this.cards.add(new Card(cardSuit, cardValue));
            }
        }
    }
    public void shuffle(){
        ArrayList<Card> tempDeck = new ArrayList<Card>();
        
        Random random = new Random();
        int randomCardindex = 0;
        int originalDeckSize = this.cards.size();
        for (int i = 0; i < originalDeckSize; i++){
            randomCardindex = random.nextInt((this.cards.size()-1) + 1);
            tempDeck.add(this.cards.get(randomCardindex));
            
            this.cards.remove(randomCardindex);
        }
        this.cards = tempDeck;
    }
    
    @Override
    public String toString(){
        String cardHand = "";
        for (Card c: this.cards){
            cardHand += "\n" + c.toString();       
        }
        return cardHand;
    }
    public void removeCard(int i){
        this.cards.remove(i);
    }
    
    public Card getCard(int i){
        return this.cards.get(i);
    }
    
    public void addCard(Card addCard){
        this.cards.add(addCard);
    }
    
    //draw from deck
    public void drawDeck(Deck comingFrom){
        this.cards.add(comingFrom.getCard(0));
        comingFrom.removeCard(0);
    }
    
    public int deckSize(){
        return this.cards.size();
    }
    
    public int cardsValue(){
        
        int total = 0;
        int aces = 0;
        
        //for each card in c, loop
        for (Card c : this.cards){
            switch(c.getValue()){
                case TWO:
                    total += 2; break;
                case THREE:
                    total += 3; break;
                case FOUR:
                    total += 4; break;
                case FIVE:
                    total += 5; break;
                case SIX:
                    total += 6; break;
                case SEVEN:
                    total += 7; break;
                case EIGHT:
                    total += 8; break;
                case NINE:
                    total += 9; break;
                case TEN:
                    total += 10; break;
                case JACK:
                    total += 10; break;
                case QUEEN:
                    total += 10; break;
                case KING: 
                    total += 10; break;
                case ACE: 
                    aces += 1; break;
            }
        }
        for (int i = 0; i < aces; i++){
                if (total > 10){
                    total += 1;
                }
                else{
                    total += 11;
                }
        }
        return total;
    }
    
    public void resetDeck(Deck moveCards){
        int deckSize = this.cards.size();
        
        for(int i = 0; i < deckSize; i++){
            moveCards.addCard(this.getCard(i));
        }
        for(int i = 0; i < deckSize; i++){
            this.removeCard(0);
        }
    }
}
