/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sheridan.orourkeb;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author benja
 */
public class BlackjackTest {
    
    /**
     * Test of main method, potential outcome 1
     * Testing to see if correct winner will be crowned upon card values
     * between dealer and player ; Testing good outcome here
     */
    @Test
    public void testOutcome1() {
        System.out.println("Testing first possible outcome");
        int playerDeckValue = 21;
        int dealerDeckValue = 20;
       
        boolean expected = true;
        boolean actual = (playerDeckValue > dealerDeckValue);
        
        assertEquals(expected, actual);
        System.out.println("Test passed");
        
    }
    /**
     * Test of main method, potential outcome 2
     * Testing to see if correct winner will be crowned upon card values
     * between dealer and player; Testing the bad outcome here
     */
    @Test
    public void testOutcome2() {
        System.out.println("Testing second possible outcome");
        int playerDeckValue = 20;
        int dealerDeckValue = 21;
       
        boolean expected = false;
        boolean actual = (playerDeckValue > dealerDeckValue);
        
        assertEquals(expected, actual);
        System.out.println("Test passed");
        
    }
    /**
     * Test of main method, potential outcome 1
     * Testing to see if correct winner will be crowned upon card values
     * between dealer and player; testing another bad boundary here (tie)
     */
    @Test
    public void testOutcome3() {
        System.out.println("Testing third possible outcome");
        int playerDeckValue = 20;
        int dealerDeckValue = 20;
       
        boolean expected = false;
        boolean actual = (playerDeckValue > dealerDeckValue);
        
        assertEquals(expected, actual);
        System.out.println("Test passed");
        
    }
    
    /**
     * Test of main method, potential outcome 1
     * Testing to see if correct winner will be crowned upon card values
     * between dealer and player; testing the boundaries here
     */
    @Test
    public void testOutcome4() {
        System.out.println("Testing third possible outcome");
        int playerDeckValue = 27;
        int dealerDeckValue = 20;
       
        boolean expected = false;
        boolean actual = (playerDeckValue > dealerDeckValue 
                && playerDeckValue <=21);
        
        assertEquals(expected, actual);
        System.out.println("Test passed");
        
    }
}
